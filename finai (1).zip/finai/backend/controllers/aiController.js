const { spawn } = require('child_process');
const path = require('path');
const axios = require('axios');
const Transaction = require('../models/Transaction');

// Runs the Python ML model for rule-based budget suggestions.
const runBudgetModel = (transactions) =>
  new Promise((resolve, reject) => {
    const scriptPath = path.join(__dirname, '..', 'ml', 'budget_suggestion.py');
    const py = spawn('python3', [scriptPath]);

    let output = '';
    let errOutput = '';
    py.stdout.on('data', (d) => (output += d.toString()));
    py.stderr.on('data', (d) => (errOutput += d.toString()));

    py.on('close', (code) => {
      if (code !== 0) return reject(new Error(errOutput || 'ML script failed'));
      try {
        resolve(JSON.parse(output));
      } catch (e) {
        reject(e);
      }
    });

    py.stdin.write(JSON.stringify({ transactions }));
    py.stdin.end();
  });

// GET /api/ai/budget-suggestions
exports.getBudgetSuggestions = async (req, res) => {
  try {
    const transactions = await Transaction.find({ user: req.user._id }).select('category amount date type');
    const result = await runBudgetModel(transactions);
    res.json({ success: true, ...result });
  } catch (err) {
    res.status(500).json({ success: false, message: 'AI model error: ' + err.message });
  }
};

// POST /api/ai/insights  { prompt }
// Uses an LLM for natural-language financial insights when ANTHROPIC_API_KEY is set,
// otherwise falls back to a deterministic rule-based summary built from the user's data.
exports.getAIInsights = async (req, res) => {
  try {
    const { prompt } = req.body;
    const transactions = await Transaction.find({ user: req.user._id }).sort({ date: -1 }).limit(100);

    if (process.env.ANTHROPIC_API_KEY) {
      const summary = transactions
        .map((t) => `${t.date.toISOString().slice(0, 10)} | ${t.category} | ${t.amount}`)
        .join('\n');

      const response = await axios.post(
        'https://api.anthropic.com/v1/messages',
        {
          model: 'claude-sonnet-4-6',
          max_tokens: 500,
          messages: [
            {
              role: 'user',
              content: `You are a personal finance assistant. Here is the user's recent transaction history (date | category | amount, negative = expense):\n\n${summary}\n\nUser question: ${
                prompt || 'Give me 3 short, actionable insights about my spending.'
              }`,
            },
          ],
        },
        {
          headers: {
            'x-api-key': process.env.ANTHROPIC_API_KEY,
            'anthropic-version': '2023-06-01',
            'content-type': 'application/json',
          },
        }
      );
      const text = response.data.content.map((c) => c.text || '').join('\n');
      return res.json({ success: true, source: 'llm', insight: text });
    }

    // Fallback: deterministic rule-based insight (no external API key needed)
    const totalExpense = Math.abs(
      transactions.filter((t) => t.type === 'expense').reduce((s, t) => s + t.amount, 0)
    );
    const byCategory = {};
    transactions
      .filter((t) => t.type === 'expense')
      .forEach((t) => {
        byCategory[t.category] = (byCategory[t.category] || 0) + Math.abs(t.amount);
      });
    const top = Object.entries(byCategory).sort((a, b) => b[1] - a[1])[0];

    const insight = top
      ? `Your highest spending category is ${top[0]} at ${top[1].toFixed(
          2
        )}, which is ${((top[1] / (totalExpense || 1)) * 100).toFixed(
          1
        )}% of your total expenses. Consider setting a stricter budget limit for this category.`
      : 'Add a few transactions to start receiving personalized AI insights.';

    res.json({ success: true, source: 'rule-based', insight });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
