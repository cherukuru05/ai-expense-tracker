const Budget = require('../models/Budget');
const Transaction = require('../models/Transaction');

const currentMonth = () => new Date().toISOString().slice(0, 7);

exports.getBudgets = async (req, res) => {
  try {
    const month = req.query.month || currentMonth();
    const budgets = await Budget.find({ user: req.user._id, month });

    const start = new Date(`${month}-01T00:00:00.000Z`);
    const end = new Date(start);
    end.setMonth(end.getMonth() + 1);

    const txs = await Transaction.find({
      user: req.user._id,
      type: 'expense',
      date: { $gte: start, $lt: end },
    });

    const spentByCategory = {};
    txs.forEach((t) => {
      spentByCategory[t.category] = (spentByCategory[t.category] || 0) + Math.abs(t.amount);
    });

    const result = budgets.map((b) => ({
      id: b._id,
      category: b.category,
      limit: b.limit,
      month: b.month,
      spent: spentByCategory[b.category] || 0,
    }));

    res.json({ success: true, budgets: result });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.upsertBudget = async (req, res) => {
  try {
    const { category, limit, month } = req.body;
    if (!category || limit === undefined) {
      return res.status(400).json({ success: false, message: 'category and limit are required' });
    }
    const targetMonth = month || currentMonth();
    const budget = await Budget.findOneAndUpdate(
      { user: req.user._id, category, month: targetMonth },
      { limit },
      { new: true, upsert: true }
    );
    res.json({ success: true, budget });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.deleteBudget = async (req, res) => {
  try {
    const budget = await Budget.findOneAndDelete({ _id: req.params.id, user: req.user._id });
    if (!budget) return res.status(404).json({ success: false, message: 'Budget not found' });
    res.json({ success: true, message: 'Deleted' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
