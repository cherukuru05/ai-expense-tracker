const Transaction = require('../models/Transaction');

// GET /api/reports/monthly?year=2024
exports.getMonthlyReport = async (req, res) => {
  try {
    const year = req.query.year || new Date().getFullYear();
    const start = new Date(`${year}-01-01T00:00:00.000Z`);
    const end = new Date(`${year}-12-31T23:59:59.999Z`);

    const transactions = await Transaction.find({
      user: req.user._id,
      date: { $gte: start, $lte: end },
    });

    const months = Array.from({ length: 12 }, (_, i) => String(i + 1).padStart(2, '0'));
    const report = months.map((m) => {
      const monthTx = transactions.filter((t) => t.date.toISOString().slice(5, 7) === m);
      const income = monthTx.filter((t) => t.type === 'income').reduce((s, t) => s + t.amount, 0);
      const expense = Math.abs(monthTx.filter((t) => t.type === 'expense').reduce((s, t) => s + t.amount, 0));
      return { month: `${year}-${m}`, income, expense, net: income - expense };
    });

    res.json({ success: true, year, report });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// GET /api/reports/export.csv - simple CSV export of all transactions
exports.exportCsv = async (req, res) => {
  try {
    const transactions = await Transaction.find({ user: req.user._id }).sort({ date: -1 });
    const header = 'Date,Description,Category,Type,Amount\n';
    const rows = transactions
      .map((t) => `${t.date.toISOString().slice(0, 10)},"${t.desc}",${t.category},${t.type},${t.amount}`)
      .join('\n');

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="finai_transactions.csv"');
    res.send(header + rows);
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
