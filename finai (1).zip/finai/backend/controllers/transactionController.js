const Transaction = require('../models/Transaction');

exports.getTransactions = async (req, res) => {
  try {
    const { category, type, from, to, search, page = 1, limit = 50 } = req.query;
    const q = { user: req.user._id };
    if (category && category !== 'All') q.category = category;
    if (type) q.type = type;
    if (from || to) {
      q.date = {};
      if (from) q.date.$gte = new Date(from);
      if (to) q.date.$lte = new Date(to);
    }
    if (search) q.desc = { $regex: search, $options: 'i' };

    const transactions = await Transaction.find(q)
      .sort({ date: -1 })
      .skip((page - 1) * limit)
      .limit(Number(limit));
    const total = await Transaction.countDocuments(q);

    res.json({ success: true, count: transactions.length, total, transactions });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.createTransaction = async (req, res) => {
  try {
    const { desc, category, amount, type, date, icon, notes } = req.body;
    if (!desc || !category || amount === undefined || !type || !date) {
      return res.status(400).json({ success: false, message: 'Missing required fields' });
    }
    const signedAmount = type === 'expense' ? -Math.abs(amount) : Math.abs(amount);
    const tx = await Transaction.create({
      user: req.user._id,
      desc,
      category,
      amount: signedAmount,
      type,
      date,
      icon,
      notes,
    });
    res.status(201).json({ success: true, transaction: tx });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.updateTransaction = async (req, res) => {
  try {
    const tx = await Transaction.findOne({ _id: req.params.id, user: req.user._id });
    if (!tx) return res.status(404).json({ success: false, message: 'Transaction not found' });

    const fields = ['desc', 'category', 'date', 'icon', 'notes', 'type'];
    fields.forEach((f) => {
      if (req.body[f] !== undefined) tx[f] = req.body[f];
    });
    if (req.body.amount !== undefined) {
      tx.amount = tx.type === 'expense' ? -Math.abs(req.body.amount) : Math.abs(req.body.amount);
    }
    await tx.save();
    res.json({ success: true, transaction: tx });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.deleteTransaction = async (req, res) => {
  try {
    const tx = await Transaction.findOneAndDelete({ _id: req.params.id, user: req.user._id });
    if (!tx) return res.status(404).json({ success: false, message: 'Transaction not found' });
    res.json({ success: true, message: 'Deleted' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.getAnalyticsSummary = async (req, res) => {
  try {
    const transactions = await Transaction.find({ user: req.user._id });
    const totalIncome = transactions.filter((t) => t.type === 'income').reduce((s, t) => s + t.amount, 0);
    const totalExpense = Math.abs(transactions.filter((t) => t.type === 'expense').reduce((s, t) => s + t.amount, 0));

    const byCategory = {};
    transactions
      .filter((t) => t.type === 'expense')
      .forEach((t) => {
        byCategory[t.category] = (byCategory[t.category] || 0) + Math.abs(t.amount);
      });

    const monthly = {};
    transactions.forEach((t) => {
      const key = new Date(t.date).toISOString().slice(0, 7); // YYYY-MM
      if (!monthly[key]) monthly[key] = { income: 0, expense: 0 };
      if (t.type === 'income') monthly[key].income += t.amount;
      else monthly[key].expense += Math.abs(t.amount);
    });

    res.json({
      success: true,
      totalIncome,
      totalExpense,
      netSavings: totalIncome - totalExpense,
      byCategory,
      monthly,
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
