"""
Lightweight ML model for AI Financial Expense Tracker.

Given a JSON payload of past transactions (passed via stdin), this script:
  1. Computes per-category spending trends (month-over-month % change)
  2. Flags categories that are overspending relative to historical average
  3. Suggests a recommended budget limit per category using a weighted
     moving average + a savings-buffer heuristic (simple, explainable ML
     rather than a black-box model, appropriate for personal finance advice)

Usage (called by Node.js backend via child_process):
    python3 budget_suggestion.py < input.json

Input JSON shape:
{
  "transactions": [
    {"category": "Food", "amount": -87.43, "date": "2024-06-09", "type": "expense"},
    ...
  ]
}

Output JSON shape:
{
  "suggestions": [
    {"category": "Food", "avgMonthlySpend": 320.5, "suggestedLimit": 352.5,
     "trendPct": 12.4, "alert": "Spending trending up"}
  ]
}
"""

import sys
import json
from collections import defaultdict
from datetime import datetime


def month_key(date_str):
    return date_str[:7]  # 'YYYY-MM'


def main():
    raw = sys.stdin.read()
    try:
        payload = json.loads(raw) if raw.strip() else {"transactions": []}
    except json.JSONDecodeError:
        payload = {"transactions": []}

    transactions = payload.get("transactions", [])

    # category -> month -> total spend
    by_cat_month = defaultdict(lambda: defaultdict(float))

    for t in transactions:
        if t.get("type") != "expense":
            continue
        cat = t.get("category", "Other")
        m = month_key(t.get("date", ""))
        if not m:
            continue
        by_cat_month[cat][m] += abs(t.get("amount", 0))

    suggestions = []
    for cat, months in by_cat_month.items():
        sorted_months = sorted(months.keys())
        values = [months[m] for m in sorted_months]
        if not values:
            continue

        avg = sum(values) / len(values)

        # weighted moving average: recent months weigh more
        weights = list(range(1, len(values) + 1))
        weighted_avg = sum(v * w for v, w in zip(values, weights)) / sum(weights)

        # trend: compare last value to average of all prior values
        if len(values) >= 2:
            prior_avg = sum(values[:-1]) / len(values[:-1])
            trend_pct = ((values[-1] - prior_avg) / prior_avg * 100) if prior_avg else 0
        else:
            trend_pct = 0

        # suggested limit = weighted average + 10% buffer, rounded to nearest 5
        suggested_limit = round((weighted_avg * 1.10) / 5) * 5

        alert = None
        if trend_pct > 15:
            alert = f"{cat} spending trending up {round(trend_pct, 1)}% — consider tightening budget"
        elif trend_pct < -15:
            alert = f"{cat} spending trending down {round(abs(trend_pct), 1)}% — good progress"

        suggestions.append({
            "category": cat,
            "avgMonthlySpend": round(avg, 2),
            "suggestedLimit": suggested_limit,
            "trendPct": round(trend_pct, 1),
            "alert": alert,
        })

    suggestions.sort(key=lambda s: s["avgMonthlySpend"], reverse=True)
    print(json.dumps({"suggestions": suggestions}))


if __name__ == "__main__":
    main()
