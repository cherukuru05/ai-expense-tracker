const mongoose = require('mongoose');

const reminderSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    title: { type: String, required: true },
    description: { type: String, default: '' },
    amount: { type: Number, default: 0 },
    dueDate: { type: Date, required: true },
    recurring: { type: String, enum: ['none', 'weekly', 'monthly', 'yearly'], default: 'none' },
    color: { type: String, default: '#5b8def' },
    isPaid: { type: Boolean, default: false },
    unread: { type: Boolean, default: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Reminder', reminderSchema);
