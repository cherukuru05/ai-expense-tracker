const mongoose = require('mongoose');

const transactionSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    desc: { type: String, required: true, trim: true },
    category: {
      type: String,
      required: true,
      enum: ['Food', 'Travel', 'Shopping', 'Bills', 'Health', 'Entertainment', 'Education', 'Other', 'Salary'],
    },
    amount: { type: Number, required: true }, // positive = income, negative = expense
    type: { type: String, enum: ['income', 'expense'], required: true },
    date: { type: Date, required: true },
    icon: { type: String, default: 'ti-receipt' },
    notes: { type: String, default: '' },
  },
  { timestamps: true }
);

transactionSchema.index({ user: 1, date: -1 });

module.exports = mongoose.model('Transaction', transactionSchema);
