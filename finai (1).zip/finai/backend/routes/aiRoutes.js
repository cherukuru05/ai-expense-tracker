const express = require('express');
const router = express.Router();
const { getBudgetSuggestions, getAIInsights } = require('../controllers/aiController');
const { protect } = require('../middleware/auth');

router.use(protect);

router.get('/budget-suggestions', getBudgetSuggestions);
router.post('/insights', getAIInsights);

module.exports = router;
