require('dotenv').config();
const connectDB = require('./config/db');
const User = require('./models/User');
const Transaction = require('./models/Transaction');
const Budget = require('./models/Budget');
const Reminder = require('./models/Reminder');

const TRANSACTIONS = [
  { desc: 'Netflix Subscription', category: 'Entertainment', amount: -14.99, date: '2024-06-10', type: 'expense', icon: 'ti-device-tv' },
  { desc: 'Monthly Salary', category: 'Salary', amount: 5200, date: '2024-06-01', type: 'income', icon: 'ti-cash' },
  { desc: 'Grocery Store', category: 'Food', amount: -87.43, date: '2024-06-09', type: 'expense', icon: 'ti-shopping-cart' },
  { desc: 'Electricity Bill', category: 'Bills', amount: -124.5, date: '2024-06-08', type: 'expense', icon: 'ti-bolt' },
  { desc: 'Flight Tickets', category: 'Travel', amount: -340, date: '2024-06-07', type: 'expense', icon: 'ti-plane' },
  { desc: 'Freelance Project', category: 'Salary', amount: 800, date: '2024-06-06', type: 'income', icon: 'ti-briefcase' },
  { desc: 'Amazon Shopping', category: 'Shopping', amount: -62.18, date: '2024-06-05', type: 'expense', icon: 'ti-shopping-bag' },
  { desc: 'Gym Membership', category: 'Health', amount: -45, date: '2024-06-04', type: 'expense', icon: 'ti-heart-rate-monitor' },
  { desc: 'Restaurant Dinner', category: 'Food', amount: -48.25, date: '2024-06-03', type: 'expense', icon: 'ti-tools-kitchen-2' },
  { desc: 'Spotify Premium', category: 'Entertainment', amount: -9.99, date: '2024-06-02', type: 'expense', icon: 'ti-music' },
  { desc: 'Online Course', category: 'Education', amount: -199, date: '2024-06-01', type: 'expense', icon: 'ti-book' },
  { desc: 'Doctor Visit', category: 'Health', amount: -80, date: '2024-05-30', type: 'expense', icon: 'ti-stethoscope' },
];

const BUDGETS = [
  { category: 'Food', limit: 400 },
  { category: 'Entertainment', limit: 100 },
  { category: 'Travel', limit: 500 },
  { category: 'Bills', limit: 300 },
  { category: 'Shopping', limit: 200 },
  { category: 'Health', limit: 150 },
];

const REMINDERS = [
  { title: 'Electricity Bill Due', description: '₹124.50 due soon', amount: 124.5, dueDate: '2024-06-12', color: '#ef4444' },
  { title: 'Gym Membership Renewal', description: 'Monthly auto-renew', amount: 45, dueDate: '2024-06-15', color: '#06d6a0' },
];

(async () => {
  await connectDB();

  await Promise.all([User.deleteMany({}), Transaction.deleteMany({}), Budget.deleteMany({}), Reminder.deleteMany({})]);

  const demoUser = await User.create({
    name: 'Komal P.',
    email: 'komal@email.com',
    password: 'password123',
    role: 'admin',
    avatarInitials: 'KP',
  });

  await Transaction.insertMany(TRANSACTIONS.map((t) => ({ ...t, user: demoUser._id })));
  await Budget.insertMany(BUDGETS.map((b) => ({ ...b, user: demoUser._id, month: '2024-06' })));
  await Reminder.insertMany(REMINDERS.map((r) => ({ ...r, user: demoUser._id })));

  console.log('[Seed] Done. Demo login -> email: komal@email.com / password: password123');
  process.exit(0);
})();
